import glob
import pandas as pd


path_raw0 = r"..\Raw" + "\\"
path_csv0 = r"..\CSV" + "\\"
file_station = r"..\Station Info.csv"

col_list = ["River", "Station", "Lon", "Lat", "Date", "Discharge"]

col_dict = {
    "river": "River",
    "station_name": "Station",
    "date": "Date",
    "discharge": "Discharge",
}
river_dict = {
    "Northern_Dvina": "Northern Dvina",
}
station_dict = {
    "Indigirskiy": "Indigirsky",
    "Ust'-Penega": "Ust' Pinega",
    "Ust'-Tsil'ma": "Ust' Tsil'ma",
    "Malonisogorskoe": "Malonisogorskoye",
    "7.5_km_down_of_Buur.s_mouth": "7.5 km down of Buur's mouth",
}


df_station = pd.read_csv(file_station, index_col="Station")
station_list = df_station.index.unique()
river_list = df_station["River"].unique()

file_list = glob.glob(path_raw0 + "*.xlsx")
file_list.sort()

for file in file_list[:]:
    print(file)

    df = pd.read_excel(file, parse_dates=["date"])
    df.rename(columns=col_dict, inplace=True)
    df.dropna(subset=["Discharge"], inplace=True)

    river = df["River"].dropna().iat[0]
    if river in river_dict:
        river = river_dict[river]
        assert river in river_list

    station = df["Station"].dropna().iat[0]
    if station not in station_list:
        station = station_dict[station]
        assert station in station_list

    river_station = f"{river}__{station}"

    df["Station"] = station
    df["Lon"] = df_station.at[station, "Lon"]
    df["Lat"] = df_station.at[station, "Lat"]
    df = df[col_list]

    file_csv = path_csv0 + f"{river_station}.csv"
    df.to_csv(file_csv, index=False)
