import joblib
import warnings
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import make_scorer, mean_squared_error, r2_score
from sklearn.model_selection import RandomizedSearchCV, TimeSeriesSplit
from sklearn.feature_selection import RFE
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from xgboost import XGBRegressor
import lightgbm as lgb
from lightgbm import LGBMRegressor
import my_module.plotting as mpt

warnings.filterwarnings("ignore", category=pd.errors.PerformanceWarning)


# ========================= 1. Global Configuration =========================
# Paths
PATH_DF = r"Table" + "\\"
PATH_MODEL = r"Model" + "\\"
PATH_FIG = r"Figure" + "\\"

# Data split ratios
TRAIN_RATIO = 0.70
VAL_RATIO = 0.15
# Test ratio is 1 - (TRAIN_RATIO + VAL_RATIO)

# Model parameters
N_INITIAL_FEATURES = 50  # Number of features after initial selection
N_FINAL_FEATURES = 20  # Number of features after final selection
RANDOM_STATE = 42

# Peak value parameters
PEAK_QUANTILE = 0.90  # Threshold for peak flow classification
OVERSAMPLE_FACTOR = 10  # Factor for oversampling peak flow data
PEAK_NUM = 5  # Number of peak flow days to consider

# Early stopping parameters
EARLY_STOPPING_SIZE = 0.10  # Proportion of data used for early stopping
EARLY_STOPPING_ROUNDS = 40  # Number of rounds for early stopping
MAX_EPOCHS = 500

mpt.set_font()


# ========================= 2. Utility Functions =========================
def add_noise(df, noise_level=0.01):
    """Add Gaussian noise to dataframe values."""
    return df + np.random.normal(0, noise_level, df.shape)


def calc_rmse_r2(y_true, y_pred):
    """Calculate RMSE and R²."""
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    r2 = r2_score(y_true, y_pred)
    return rmse, r2


def evaluate_peak_flow(y_true, y_pred, n_peaks=PEAK_NUM, min_days=240):
    """Evaluate prediction performance for peak flow periods."""
    df_eval = pd.DataFrame({"y_true": y_true, "y_pred": y_pred}, index=y_true.index)

    peak_flow_data_idx = []
    for year in df_eval.index.year.unique():
        df_year = df_eval[df_eval.index.year == year]
        if len(df_year) >= min_days:
            # peak_days = df_year.nlargest(n_peaks, "y_true")
            # peak_flow_data.append(peak_days)
            idx = df_year.nlargest(n_peaks, "y_true").index
            peak_flow_data_idx.extend(idx)

    if peak_flow_data_idx:
        y_true_peak = df_eval.loc[peak_flow_data_idx, "y_true"]
        y_pred_peak = df_eval.loc[peak_flow_data_idx, "y_pred"]
        rmse, r2 = calc_rmse_r2(y_true_peak, y_pred_peak)

        # Calculate Spearman correlation
        # mean by year
        y_true_peak_mean = y_true_peak.groupby(y_true_peak.index.year).mean()
        y_pred_peak_mean = y_pred_peak.groupby(y_pred_peak.index.year).mean()
        r_spearman, _ = stats.spearmanr(y_true_peak_mean, y_pred_peak_mean)

        return rmse, r2, r_spearman
    return np.nan, np.nan, np.nan


def create_early_stopping_split(
    X_combined, y_combined, early_stopping_size=EARLY_STOPPING_SIZE
):
    """
    Split the combined data into training and early stopping sets.

    Args:
        X_combined: Combined feature data.
        y_combined: Combined target data.
        early_stopping_size: Proportion of data used for early stopping.

    Returns:
        X_train_final: Final training data.
        y_train_final: Final training labels.
        X_early_stop: Early stopping evaluation data.
        y_early_stop: Early stopping evaluation labels.
    """

    # If the data has a time index, keep the time order
    if isinstance(X_combined.index, pd.DatetimeIndex):
        split_idx = int(len(X_combined) * (1 - early_stopping_size))
        X_train_final = X_combined.iloc[:split_idx]
        y_train_final = y_combined.iloc[:split_idx]
        X_early_stop = X_combined.iloc[split_idx:]
        y_early_stop = y_combined.iloc[split_idx:]
    else:
        # If not time series data, randomly split
        from sklearn.model_selection import train_test_split

        X_train_final, X_early_stop, y_train_final, y_early_stop = train_test_split(
            X_combined,
            y_combined,
            test_size=early_stopping_size,
            random_state=RANDOM_STATE,
        )

    return X_train_final, y_train_final, X_early_stop, y_early_stop


# ========================= 3. Data Processing Class =========================
class RiverFlowDataProcessor:
    def __init__(self, file_path):
        self.file_path = file_path
        self.df = None
        self.scaler = StandardScaler()

    def load_data(self):
        """Load and preprocess the data."""
        self.df = pd.read_csv(self.file_path, parse_dates=["Date"])
        self.df.set_index("Date", inplace=True)
        self.df.sort_index(inplace=True)
        self.df.dropna(inplace=True)
        # self.df = self.df.sample(frac=0.05, random_state=RANDOM_STATE)
        return self

    def get_features_target(self):
        """Extract features and target variables."""
        self.input_features = self.df.drop(
            columns=["River", "Station", "Discharge"]
        ).columns
        self.target_variable = "Discharge"
        return self.input_features, self.target_variable

    def split_data(self, train_ratio=TRAIN_RATIO, val_ratio=VAL_RATIO):
        """Split data into train, validation, and test sets."""
        n = len(self.df)
        train_end = int(n * train_ratio)
        val_end = int(n * (train_ratio + val_ratio))

        X = self.df[self.input_features]
        y = self.df[self.target_variable]

        self.X_train = X.iloc[:train_end]
        self.y_train = y.iloc[:train_end]
        self.X_val = X.iloc[train_end:val_end]
        self.y_val = y.iloc[train_end:val_end]
        self.X_test = X.iloc[val_end:]
        self.y_test = y.iloc[val_end:]

        return (
            (self.X_train, self.y_train),
            (self.X_val, self.y_val),
            (self.X_test, self.y_test),
        )

    def augment_peak_flows(
        self, quantile=PEAK_QUANTILE, oversample_factor=OVERSAMPLE_FACTOR
    ):
        """Augment peak flow samples in training data."""
        np.random.seed(RANDOM_STATE)

        # Determine the peak threshold and identify peak samples
        peak_threshold = self.y_train.quantile(quantile)
        peak_mask = self.y_train >= peak_threshold

        # Get peak flow data
        X_train_peak = self.X_train[peak_mask].copy()
        y_train_peak = self.y_train[peak_mask].copy()

        # Add a column to indicate whether the data is augmented
        X_train_original = self.X_train.copy()
        X_train_original["is_augmented"] = False

        # Create a list to store all augmented data
        augmented_X_list = []
        augmented_y_list = []

        # Generate multiple lists of augmented data
        for i in range(oversample_factor):
            # Add noise to the features
            X_train_peak_aug = add_noise(X_train_peak, noise_level=0.01)
            X_train_peak_aug["is_augmented"] = True

            # Add noise to the target variable
            y_train_peak_aug = y_train_peak + np.random.normal(
                0, y_train_peak.std() * 0.01, y_train_peak.shape
            )

            # Ensure the index of augmented data matches the original peak data
            X_train_peak_aug.index = X_train_peak.index
            y_train_peak_aug.index = y_train_peak.index

            augmented_X_list.append(X_train_peak_aug)
            augmented_y_list.append(y_train_peak_aug)

        # Merge original data with augmented data
        # Insert original data at the beginning
        augmented_X_list.insert(0, X_train_original)
        augmented_y_list.insert(0, self.y_train)

        self.X_aug = pd.concat(augmented_X_list)
        self.y_aug = pd.concat(augmented_y_list)

        return self.X_aug, self.y_aug


# ========================= 4. Model Factory =========================
class ModelFactory:
    """Factory class for creating different types of models with their configurations."""

    @staticmethod
    def get_model_config(model_type):
        """Get model configuration including base model, parameters grid, and specific settings."""
        configs = {
            "XGBoost": {
                "model": XGBRegressor(
                    objective="reg:squarederror",
                    eval_metric="rmse",
                    random_state=RANDOM_STATE,
                    n_jobs=-1,
                ),
                "param_grid": {
                    "max_depth": [2, 3],
                    "learning_rate": [0.005, 0.01],
                    "subsample": [0.4, 0.5],
                    "colsample_bytree": [0.4, 0.5],
                    "reg_lambda": [30, 50, 100],
                    "reg_alpha": [2, 5, 10],
                    "min_child_weight": [5, 7, 10],
                },
                "supports_early_stopping": True,
            },
            "LightGBM": {
                "model": LGBMRegressor(random_state=RANDOM_STATE, n_jobs=-1),
                "param_grid": {
                    "max_depth": [2, 3],
                    "num_leaves": [4, 7, 15],
                    "learning_rate": [0.001, 0.005, 0.01],
                    "feature_fraction": [0.4, 0.5],
                    "bagging_fraction": [0.4, 0.5],
                    "bagging_freq": [5, 7],
                    "min_child_samples": [100, 200, 300],
                    "min_data_in_leaf": [50, 100, 150],
                    "reg_alpha": [1.0, 5.0, 10.0],
                    "reg_lambda": [1.0, 5.0, 10.0],
                    "max_bin": [64, 128],
                    "min_split_gain": [0.3, 0.5],
                    "path_smooth": [1.0, 3.0],
                },
                "supports_early_stopping": True,
            },
            "RF": {
                "model": RandomForestRegressor(
                    random_state=RANDOM_STATE,
                    n_jobs=-1,
                    bootstrap=True,
                    oob_score=True,
                    max_samples=0.7,
                ),
                "param_grid": {
                    "n_estimators": [100, 200, 300],
                    "max_depth": [2, 3],
                    "min_samples_split": [15, 20, 30],
                    "min_samples_leaf": [15, 20, 30],
                    "max_features": [0.3, 0.4],
                    "max_leaf_nodes": [10, 15, 20],
                    "min_impurity_decrease": [0.1, 0.15, 0.2],
                },
                "supports_early_stopping": False,
            },
            "GB": {
                "model": GradientBoostingRegressor(
                    random_state=RANDOM_STATE, n_iter_no_change=EARLY_STOPPING_ROUNDS
                ),
                "param_grid": {
                    "n_estimators": [300, 400, 500],
                    "learning_rate": [0.001, 0.005, 0.01],
                    "max_depth": [2, 3],
                    "min_samples_split": [10, 20, 30],
                    "min_samples_leaf": [5, 10, 15],
                    "subsample": [0.6, 0.7, 0.8],
                    "max_features": [0.3, 0.5, 0.7],
                    "min_impurity_decrease": [0.1, 0.2],
                },
                "supports_early_stopping": True,
            },
        }

        if model_type not in configs:
            raise ValueError(f"Unsupported model type: {model_type}")

        return configs[model_type]


# ========================= 5. River Flow Model Class =========================
class RiverFlowModel:
    def __init__(self, model_type="XGBoost"):
        self.model_type = model_type
        self.model_config = ModelFactory.get_model_config(model_type)
        self.model = None
        self.best_params = None
        self.feature_selector = None
        self.threshold = None

    def select_features(
        self, X_train, y_train, n_initial=N_INITIAL_FEATURES, n_final=N_FINAL_FEATURES
    ):
        self.threshold = np.percentile(y_train, 100 * PEAK_QUANTILE)

        """Perform two-stage feature selection and export final features to CSV."""
        # Initial feature selection using model's feature importance
        if hasattr(self.model_config["model"], "feature_importances_"):
            model_fs = self.model_config["model"]
            model_fs.fit(X_train, y_train)
            feature_importances = model_fs.feature_importances_
            initial_features = np.argsort(feature_importances)[::-1][:n_initial]
            X_train_initial = X_train.iloc[:, initial_features]
            initial_importance = feature_importances[initial_features]
        else:
            # Use correlation for initial selection
            correlations = []
            for col in X_train.columns:
                corr = abs(stats.pearsonr(X_train[col], y_train)[0])
                correlations.append((col, corr))
            correlations.sort(key=lambda x: x[1], reverse=True)
            initial_features = [col for col, _ in correlations[:n_initial]]
            X_train_initial = X_train[initial_features]
            initial_importance = [corr for _, corr in correlations[:n_initial]]

        # Final feature selection using RFE
        base_model = self.model_config["model"]
        rfe = RFE(estimator=base_model, n_features_to_select=n_final, step=1)
        rfe.fit(X_train_initial, y_train)

        # Get final selected features
        final_features = X_train_initial.columns[rfe.support_].tolist()

        # Create DataFrame with feature information
        feature_df = pd.DataFrame(
            {
                "Feature": final_features,
                "Initial_Importance": [
                    initial_importance[i]
                    for i, feat in enumerate(X_train_initial.columns)
                    if feat in final_features
                ],
                "RFE_Ranking": [
                    rfe.ranking_[i]
                    for i, feat in enumerate(X_train_initial.columns)
                    if feat in final_features
                ],
            }
        )
        feature_df = feature_df.sort_values("Initial_Importance", ascending=False)

        # Export to CSV
        file_feature = PATH_MODEL + f"Feature\\{self.model_type}_selected_features.csv"
        feature_df.to_csv(file_feature, index=False)

        self.feature_selector = {"initial_features": initial_features, "rfe": rfe}
        return final_features

    def tune_hyperparameters(self, X_train, y_train):
        """Tune model hyperparameters."""
        tscv = TimeSeriesSplit(n_splits=5)
        base_model = self.model_config["model"]
        param_grid = self.model_config["param_grid"]

        # Create scorers
        nse_scorer = make_scorer(r2_score, greater_is_better=True)

        scoring = {
            "RMSE": "neg_root_mean_squared_error",
            "NSE": nse_scorer,
        }

        # Perform random search
        random_search = RandomizedSearchCV(
            estimator=base_model,
            param_distributions=param_grid,
            n_iter=100,
            cv=tscv,
            scoring=scoring,
            refit="NSE",
            verbose=2,
            random_state=RANDOM_STATE,
            n_jobs=-1,
        )
        random_search.fit(X_train, y_train)

        self.best_params = random_search.best_params_
        return self.best_params

    def predict(self, X):
        y_pred = self.model.predict(X)
        return y_pred.clip(min=0)

    def initialize_model(self):
        # Initialize the first round model with the best parameters
        if self.model_type == "XGBoost":
            self.model = XGBRegressor(
                objective="reg:squarederror",
                eval_metric="rmse",
                n_estimators=MAX_EPOCHS,
                **self.best_params,
                random_state=RANDOM_STATE,
                n_jobs=-1,
            )
        elif self.model_type == "LightGBM":
            self.model = LGBMRegressor(
                n_estimators=MAX_EPOCHS,
                **self.best_params,
                random_state=RANDOM_STATE,
                n_jobs=-1,
            )
        else:
            self.model = self.model_config["model"]
            self.model.set_params(**self.best_params)

    def train_final_model(
        self, X_train, y_train, X_val, y_val, X_test, y_test, X_aug, y_aug
    ):
        """Train the final model with the proper early stopping strategy."""
        X_train_aug = pd.concat([X_train, X_aug], axis=0)
        y_train_aug = pd.concat([y_train, y_aug], axis=0)

        # Train the first round model using augmented data
        # Initialize the model with the best parameters
        self.initialize_model()
        self.model.fit(X_train_aug, y_train_aug)
        temp_model = self.model

        metrics1 = []
        metrics1.extend(self.evaluate_model(X_train, y_train, "Training", plot=True))
        metrics1.extend(self.evaluate_model(X_val, y_val, "Validation", plot=True))
        val_r2_aug = metrics1[8]
        vaL_r2_peak_aug = metrics1[10]

        # Re-train the model using original data
        self.initialize_model()
        self.model.fit(X_train, y_train)

        metrics2 = []
        metrics2.extend(self.evaluate_model(X_train, y_train, "Training", plot=True))
        metrics2.extend(self.evaluate_model(X_val, y_val, "Validation", plot=True))
        val_r2_no_aug = metrics2[8]
        val_r2_peak_no_aug = metrics2[10]

        # Compare the performance of the two models
        print("Validation R² without augmentation:", f"{val_r2_no_aug:.3f}")
        print("Validation R² with augmentation:", f"{val_r2_aug:.3f}")
        print("Validation Peak R² without augmentation:", f"{val_r2_peak_no_aug:.3f}")
        print("Validation Peak R² with augmentation:", f"{vaL_r2_peak_aug:.3f}")

        # If the augmented data model performance (overall and peak) is better, use the model trained with augmented data
        if (val_r2_aug > val_r2_no_aug) and (vaL_r2_peak_aug > val_r2_peak_no_aug):
            improved = True
        else:
            improved = False

        if improved:
            self.model = temp_model
            metrics = metrics1
            print("Augmented data improved model performance.\n")

            # Merge augmented training data with validation data
            X_combined = pd.concat([X_train_aug, X_val])
            y_combined = pd.concat([y_train_aug, y_val])
        else:
            metrics = metrics2
            print("Augmented data did NOT improve model performance.\n")

            X_combined = pd.concat([X_train, X_val])
            y_combined = pd.concat([y_train, y_val])

        # Export the model
        model_path = PATH_MODEL + f"Model\\{self.model_type}_model_first_round.pkl"
        joblib.dump(self.model, model_path)

        # For models that support early stopping, create a separate early stopping set
        if self.model_config["supports_early_stopping"]:
            X_train_final, y_train_final, X_early_stop, y_early_stop = (
                create_early_stopping_split(X_combined, y_combined)
            )

            if self.model_type == "XGBoost":
                self.model = XGBRegressor(
                    objective="reg:squarederror",
                    eval_metric="rmse",
                    random_state=RANDOM_STATE,
                    n_estimators=MAX_EPOCHS,
                    **self.best_params,
                    n_jobs=-1,
                )
                self.model.fit(
                    X_train_final,
                    y_train_final,
                    eval_set=[(X_early_stop, y_early_stop)],
                    early_stopping_rounds=EARLY_STOPPING_ROUNDS,
                    verbose=True,
                )

            elif self.model_type == "LightGBM":
                self.model = LGBMRegressor(
                    n_estimators=MAX_EPOCHS,
                    **self.best_params,
                    random_state=RANDOM_STATE,
                    n_jobs=-1,
                )
                eval_set = [(X_early_stop, y_early_stop)]
                self.model.fit(
                    X_train_final,
                    y_train_final,
                    eval_set=eval_set,
                    eval_metric="rmse",
                    callbacks=[
                        lgb.callback.early_stopping(
                            stopping_rounds=EARLY_STOPPING_ROUNDS
                        )
                    ],
                )

        else:
            # For models that do not support early stopping, use all data
            self.model = self.model_config["model"]
            self.model.set_params(**self.best_params)
            self.model.fit(X_combined, y_combined)

        # Export the final model
        model_path = PATH_MODEL + f"Model\\{self.model_type}_model_final.pkl"
        joblib.dump(self.model, model_path)

        # Export Final Train and Test Data
        X_combined.to_csv(
            PATH_MODEL + f"Set\\{self.model_type}_X_Train.csv", index=False
        )
        y_combined.to_csv(
            PATH_MODEL + f"Set\\{self.model_type}_y_Train.csv", index=False
        )
        X_test.to_csv(PATH_MODEL + f"Set\\{self.model_type}_X_Test.csv", index=False)
        y_test.to_csv(PATH_MODEL + f"Set\\{self.model_type}_y_Test.csv", index=False)

        # Final evaluation
        X_final = pd.concat([X_train, X_val])
        y_final = pd.concat([y_train, y_val])

        metrics.extend(self.evaluate_model(X_final, y_final, "Combined", plot=True))
        metrics.extend(self.evaluate_model(X_test, y_test, "Test", plot=True))
        metrics.append(improved)

        return self.model, metrics

    def evaluate_model(self, X, y_true, phase, plot=True):
        # Total metrics
        y_pred = self.predict(X)
        rmse, r2 = calc_rmse_r2(y_true, y_pred)

        # Peak flow metrics (90th percentile)
        peak_mask = y_true >= self.threshold
        y_true_peak1 = y_true[peak_mask]
        y_pred_peak1 = y_pred[peak_mask]
        peak90_rmse, peak90_r2 = calc_rmse_r2(y_true_peak1, y_pred_peak1)

        # Peak flow metrics (annual top 5)
        top5_rmse, top5_r2, top5_spearman = evaluate_peak_flow(y_true, y_pred)

        if plot:
            self.plot_predictions(y_true, y_pred, phase)

        return rmse, r2, peak90_rmse, peak90_r2, top5_rmse, top5_r2, top5_spearman

    def plot_predictions(self, y_true, y_pred, phase):
        """
        Plotting the predictions and observed values.
        Includes time series and scatter plots.
        Only original data (non-augmented) is used for plotting.
        """
        import matplotlib.pyplot as plt
        from matplotlib.dates import DateFormatter, AutoDateLocator

        df = pd.DataFrame({"Observed": y_true, "Predicted": y_pred}, index=y_true.index)
        df = df.sort_index()
        y_true = df["Observed"]
        y_pred = df["Predicted"]

        rmse, r2 = calc_rmse_r2(y_true, y_pred)

        # Time series plot
        fig_ts, ax_ts = plt.subplots(figsize=(15, 6))

        plot_index = y_true.index

        ax_ts.plot(plot_index, y_true, label="Observed", color="blue", alpha=0.7)
        ax_ts.plot(plot_index, y_pred, label="Predicted", color="red", alpha=0.7)

        locator = AutoDateLocator()
        ax_ts.xaxis.set_major_locator(locator)
        ax_ts.xaxis.set_major_formatter(DateFormatter("%Y-%m"))
        plt.xticks(rotation=45)

        ax_ts.set_title(f"Time Series ({phase})")
        ax_ts.set_xlabel("Date")
        ax_ts.set_ylabel("Discharge (m³/s)")
        ax_ts.legend(loc="upper right")
        ax_ts.grid(True)

        stats_text = f"R² = {r2:.3f}\nRMSE = {rmse:.1f} m³/s"
        ax_ts.text(
            0.02,
            0.96,
            stats_text,
            transform=ax_ts.transAxes,
            bbox=dict(facecolor="white", alpha=0.8),
            verticalalignment="top",
        )

        plt.tight_layout()
        file_fig1 = PATH_FIG + f"{self.model_type}_{phase}_timeseries.png"
        fig_ts.savefig(file_fig1, dpi=300, bbox_inches="tight")
        plt.close(fig_ts)

        # Scatter plot
        fig_scatter, ax_scatter = plt.subplots(figsize=(8, 8))

        min_val = min(y_true.min(), y_pred.min())
        max_val = max(y_true.max(), y_pred.max())
        range_val = max_val - min_val
        plot_min = min_val - range_val * 0.05
        plot_max = max_val + range_val * 0.05

        ax_scatter.scatter(
            y_true,
            y_pred,
            alpha=0.5,
            color="blue",
            label="Data points",
        )

        ax_scatter.plot(
            [plot_min, plot_max], [plot_min, plot_max], "r--", label="1:1 line"
        )

        ax_scatter.set_xlim(plot_min, plot_max)
        ax_scatter.set_ylim(plot_min, plot_max)

        ax_scatter.set_title(f"Scatter Plot ({phase})")
        ax_scatter.set_xlabel("Observed Discharge (m³/s)")
        ax_scatter.set_ylabel("Predicted Discharge (m³/s)")
        ax_scatter.grid(True)
        ax_scatter.legend(loc="upper right")

        ax_scatter.text(
            0.02,
            0.96,
            stats_text,
            transform=ax_scatter.transAxes,
            bbox=dict(facecolor="white", alpha=0.8),
            verticalalignment="top",
        )

        plt.tight_layout()
        file_fig2 = PATH_FIG + f"{self.model_type}_{phase}_scatter.png"
        fig_scatter.savefig(file_fig2, dpi=300, bbox_inches="tight")
        plt.close(fig_scatter)
